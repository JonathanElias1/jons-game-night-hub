/**
 * Jon's Game Night - Shared Scoring System
 * Include this in each game to sync scores across all games
 */

(function(window) {
  'use strict';

  const STORAGE_KEY = 'jonsGameNightData';
  const HUB_URL = '../index.html';

  // Scoring configuration per game
  const SCORING_CONFIG = {
    'Family Feud': {
      pointOptions: [
        { name: 'Top Answer', value: 10, type: 'individual' },
        { name: 'Fast Money Win', value: 20, type: 'individual' },
        { name: 'Round Win', value: 25, type: 'team' }
      ],
      maxPoints: 125
    },
    'Jeopardy': {
      pointOptions: [
        { name: 'Daily Double', value: 15, type: 'team' },
        { name: 'Round Win', value: 25, type: 'team' }
      ],
      maxPoints: 120
    },
    'Wheel of Fortune': {
      pointOptions: [
        { name: 'Bonus Round', value: 20, type: 'individual' },
        { name: 'Round Win', value: 10, type: 'team' }
      ],
      maxPoints: 100
    },
    'Price Is Right': {
      pointOptions: [
        { name: 'Game Win', value: 15, type: 'individual' },
        { name: 'Showcase Win', value: 30, type: 'individual' },
        { name: 'Perfect Bid', value: 10, type: 'individual' }
      ],
      maxPoints: 100
    },
    'Are You Smarter Than Jon': {
      pointOptions: [
        { name: 'Correct Answer', value: 10, type: 'individual' },
        { name: 'Used Lifeline', value: -5, type: 'individual' },
        { name: 'Game Win', value: 25, type: 'team' }
      ],
      maxPoints: 100
    }
  };

  // Load data from localStorage
  function loadData() {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
    } catch (e) {
      console.error('Failed to load game night data:', e);
    }
    return {
      players: [],
      teamNames: { A: 'Team A', B: 'Team B' },
      gamesPlayed: [],
      currentGame: null
    };
  }

  // Save data to localStorage
  function saveData(data) {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
    } catch (e) {
      console.error('Failed to save game night data:', e);
    }
  }

  // Get current data
  function getData() {
    return loadData();
  }

  // Get players
  function getPlayers() {
    return loadData().players || [];
  }

  // Get team names
  function getTeamNames() {
    return loadData().teamNames || { A: 'Team A', B: 'Team B' };
  }

  // Add score to a player
  function addScore(playerName, points, gameName) {
    const data = loadData();
    data.players = data.players.map(p => {
      if (p.name === playerName) {
        const newScores = { ...p.scores };
        newScores[gameName] = (newScores[gameName] || 0) + points;
        const newTotal = Object.values(newScores).reduce((a, b) => a + b, 0);
        return { ...p, scores: newScores, total: newTotal };
      }
      return p;
    });
    saveData(data);
    return data;
  }

  // Add score to entire team
  function addTeamScore(team, points, gameName) {
    const data = loadData();
    data.players = data.players.map(p => {
      if (p.team === team) {
        const newScores = { ...p.scores };
        newScores[gameName] = (newScores[gameName] || 0) + points;
        const newTotal = Object.values(newScores).reduce((a, b) => a + b, 0);
        return { ...p, scores: newScores, total: newTotal };
      }
      return p;
    });
    saveData(data);
    return data;
  }

  // Mark game as played
  function markGamePlayed(gameName) {
    const data = loadData();
    if (!data.gamesPlayed.includes(gameName)) {
      data.gamesPlayed.push(gameName);
    }
    data.currentGame = gameName;
    saveData(data);
  }

  // Get team totals
  function getTeamTotals() {
    const data = loadData();
    const teamA = data.players.filter(p => p.team === 'A').reduce((sum, p) => sum + (p.total || 0), 0);
    const teamB = data.players.filter(p => p.team === 'B').reduce((sum, p) => sum + (p.total || 0), 0);
    return { teamA, teamB };
  }

  // Get sorted leaderboard
  function getLeaderboard() {
    const data = loadData();
    return [...data.players].sort((a, b) => (b.total || 0) - (a.total || 0));
  }

  // Navigate back to hub
  function goToHub() {
    window.location.href = HUB_URL;
  }

  // Create floating score button UI
  function createScoreUI(gameName) {
    const data = loadData();
    if (!data.players || data.players.length === 0) {
      console.log('No players set up - scoring UI not shown');
      return;
    }

    markGamePlayed(gameName);
    const teamNames = getTeamNames();
    const config = SCORING_CONFIG[gameName];

    // Create floating button
    const container = document.createElement('div');
    container.id = 'game-night-scoring';
    container.innerHTML = `
      <style>
        #game-night-scoring {
          position: fixed;
          bottom: 20px;
          right: 20px;
          z-index: 99999;
          font-family: 'Poppins', system-ui, sans-serif;
        }
        #gns-toggle {
          width: 60px;
          height: 60px;
          border-radius: 50%;
          background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
          border: none;
          color: white;
          font-size: 24px;
          cursor: pointer;
          box-shadow: 0 4px 15px rgba(0,0,0,0.3);
          transition: transform 0.2s;
        }
        #gns-toggle:hover { transform: scale(1.1); }
        #gns-panel {
          display: none;
          position: absolute;
          bottom: 70px;
          right: 0;
          width: 320px;
          background: linear-gradient(135deg, #1a1a2e 0%, #16213e 100%);
          border-radius: 16px;
          padding: 16px;
          box-shadow: 0 10px 40px rgba(0,0,0,0.5);
        }
        #gns-panel.open { display: block; }
        #gns-panel h3 { color: #fff; margin: 0 0 12px 0; font-size: 16px; }
        .gns-teams { display: flex; gap: 8px; margin-bottom: 12px; }
        .gns-team { flex: 1; padding: 8px; border-radius: 8px; text-align: center; }
        .gns-team-a { background: rgba(59, 130, 246, 0.3); }
        .gns-team-b { background: rgba(239, 68, 68, 0.3); }
        .gns-team-name { color: #aaa; font-size: 11px; }
        .gns-team-score { color: #fff; font-size: 24px; font-weight: bold; }
        .gns-players { max-height: 150px; overflow-y: auto; margin-bottom: 12px; }
        .gns-player { display: flex; align-items: center; gap: 8px; padding: 6px; background: rgba(255,255,255,0.1); border-radius: 6px; margin-bottom: 4px; cursor: pointer; }
        .gns-player:hover { background: rgba(255,255,255,0.2); }
        .gns-player.selected { background: rgba(234, 179, 8, 0.4); border: 1px solid #eab308; }
        .gns-player-name { flex: 1; color: #fff; font-size: 12px; }
        .gns-player-score { color: #eab308; font-weight: bold; font-size: 12px; }
        .gns-points { display: flex; flex-wrap: wrap; gap: 6px; margin-bottom: 12px; }
        .gns-point-btn { padding: 8px 12px; border-radius: 8px; border: none; background: linear-gradient(135deg, #10b981 0%, #059669 100%); color: white; font-weight: bold; cursor: pointer; font-size: 11px; }
        .gns-point-btn:hover { opacity: 0.9; }
        .gns-point-btn:disabled { opacity: 0.5; cursor: not-allowed; }
        .gns-hub-btn { width: 100%; padding: 10px; border-radius: 8px; border: none; background: linear-gradient(135deg, #f59e0b 0%, #d97706 100%); color: white; font-weight: bold; cursor: pointer; }
        .gns-hub-btn:hover { opacity: 0.9; }
      </style>
      <div id="gns-panel">
        <h3>🎮 ${gameName} - Score Tracker</h3>
        <div class="gns-teams">
          <div class="gns-team gns-team-a">
            <div class="gns-team-name">${teamNames.A}</div>
            <div class="gns-team-score" id="gns-team-a-score">0</div>
          </div>
          <div class="gns-team gns-team-b">
            <div class="gns-team-name">${teamNames.B}</div>
            <div class="gns-team-score" id="gns-team-b-score">0</div>
          </div>
        </div>
        <div class="gns-players" id="gns-players"></div>
        <div class="gns-points" id="gns-points"></div>
        <button class="gns-hub-btn" id="gns-hub-btn">← Back to Game Hub</button>
      </div>
      <button id="gns-toggle">🎯</button>
    `;
    document.body.appendChild(container);

    // Toggle panel
    const toggle = document.getElementById('gns-toggle');
    const panel = document.getElementById('gns-panel');
    toggle.addEventListener('click', () => panel.classList.toggle('open'));

    // Hub button
    document.getElementById('gns-hub-btn').addEventListener('click', goToHub);

    // Selected players
    let selectedPlayers = [];

    // Render players
    function renderPlayers() {
      const players = getPlayers();
      const playersDiv = document.getElementById('gns-players');
      playersDiv.innerHTML = players.map(p => `
        <div class="gns-player ${selectedPlayers.includes(p.name) ? 'selected' : ''}" data-name="${p.name}">
          <span class="gns-player-name">${p.name} (${teamNames[p.team]})</span>
          <span class="gns-player-score">${p.scores[gameName] || 0} pts</span>
        </div>
      `).join('');

      // Click handlers
      playersDiv.querySelectorAll('.gns-player').forEach(el => {
        el.addEventListener('click', () => {
          const name = el.dataset.name;
          if (selectedPlayers.includes(name)) {
            selectedPlayers = selectedPlayers.filter(n => n !== name);
          } else {
            selectedPlayers.push(name);
          }
          renderPlayers();
          renderPoints();
        });
      });
    }

    // Render point buttons
    function renderPoints() {
      const pointsDiv = document.getElementById('gns-points');
      if (!config) return;
      pointsDiv.innerHTML = config.pointOptions.map(opt => `
        <button class="gns-point-btn" data-value="${opt.value}" ${selectedPlayers.length === 0 ? 'disabled' : ''}>
          ${opt.name} (+${opt.value})
        </button>
      `).join('');

      pointsDiv.querySelectorAll('.gns-point-btn').forEach(btn => {
        btn.addEventListener('click', () => {
          const value = parseInt(btn.dataset.value);
          selectedPlayers.forEach(name => addScore(name, value, gameName));
          selectedPlayers = [];
          updateUI();
        });
      });
    }

    // Update team scores
    function updateTeamScores() {
      const totals = getTeamTotals();
      document.getElementById('gns-team-a-score').textContent = totals.teamA;
      document.getElementById('gns-team-b-score').textContent = totals.teamB;
    }

    function updateUI() {
      renderPlayers();
      renderPoints();
      updateTeamScores();
    }

    updateUI();
  }

  // Expose API globally
  window.GameNightScoring = {
    loadData,
    saveData,
    getData,
    getPlayers,
    getTeamNames,
    addScore,
    addTeamScore,
    markGamePlayed,
    getTeamTotals,
    getLeaderboard,
    goToHub,
    createScoreUI,
    SCORING_CONFIG
  };

})(window);
